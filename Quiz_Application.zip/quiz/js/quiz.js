let quiz=[
    {
        question:"Generic is most similar in meaning to____",
        option:[
            "1.Branded",
            "2.Basic",
            "3.Trademarked",
            "4.Specific",
        ],
        answer:2,
    },
    {
        question:"Helicopter was invented by _____",
        option:[
            "1.Broquet",
            "2.Drinker",
            "3.Copernicus",
           "4.Cockrell",
            
        ],
        answer:1,
    },
    {
        question:"The most important feature of the Indian Parliament is that",
        option:[
            "1.It is the Union Legislature in India",
            "2.It is bicameral in nature",
            "3.It comprises of the President",
           "4.The upper House of the Parliament is never dissolved",   
        ],
        answer:3,
    },
    {
        question:"Cinematography was invented by____",
        option:[
            "1.Graham Bell",
            "2.Faraday",
            "3.Zeiss",
            "4.Edison",   
        ],
        answer:4,

    },
    {
        question:"Feroz Gandhi Award is associated with ______",
        option:[
            "1.Medical Research",
            "2.Parlimentory debate",
            "3.Preservation of worldlife",
            "4.Journalism",   
        ],
        answer:4,
    }
]